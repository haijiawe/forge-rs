// A fixture plugin: it answers one JSON-RPC request and exits.
const readline = require("readline");
const rl = readline.createInterface({ input: process.stdin });
rl.on("line", (line) => {
  const request = JSON.parse(line);
  const result = { protocolVersion: 1, name: "fixture-plugin", version: "0.3.1" };
  process.stdout.write(JSON.stringify({ jsonrpc: "2.0", id: request.id, result }) + "\n");
});